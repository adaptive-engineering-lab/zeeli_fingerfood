function App() {
  return (
    <div>
      <h1>Zeeli Finger Foods</h1>
      <p>Menu, cart, checkout, and admin routes go here — see the PRD build phases.</p>
    </div>
  )
}

export default App
