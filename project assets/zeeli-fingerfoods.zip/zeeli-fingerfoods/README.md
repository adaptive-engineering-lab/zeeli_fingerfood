# Zeeli Finger Foods — Ordering SPA

See `docs/prd.md` for the full product spec (this file is generated from the project's PRD — feed it to speckit's `/specify`).

## Stack
- React + Vite
- Supabase (Postgres + Storage + Auth + Realtime) — project `zeeli-fingerfoods` (`rhkioufbffisvpfwavly`, eu-west-1)
- Vitest + React Testing Library for TDD
- Deploys to Vercel

## Supabase setup (already done for this project)
- **Schema**: `categories`, `menu_items`, `menu_item_variants`, `orders`, `order_items` — see migration `initial_schema`.
- **RLS**: public can read available menu items/variants and insert orders; only authenticated (admin) users can write menu data or read/update orders.
- **Storage**: `menu-images` bucket, public read, admin write — for item photos.
- **Realtime**: enabled on `orders` for the admin dashboard's live new-order alert.

To connect a fresh clone to this same Supabase project, copy `.env.example` to `.env` — it's already filled in with this project's public URL and publishable key (safe to commit as an example; the values are not secret, they're the anon/publishable pair Supabase designs for frontend use).

## Getting started
```bash
npm install
cp .env.example .env   # already pre-filled — just confirm it, or add your own project's values
npm run dev
```

## Testing (TDD)
```bash
npm run test        # run once
npm run test:watch  # watch mode
```
Write the failing test first, then the implementation — see `src/features/cart/cartMath.{js,test.js}` for the pattern used throughout this project.

## Project structure
```
src/
  lib/              # Supabase client, shared utilities
  features/
    menu/           # customer-facing browse (Phase 3)
    cart/           # cart state + math (Phase 4)
    checkout/       # checkout form + WhatsApp handoff (Phase 5)
    admin/          # admin auth, menu CRUD, orders dashboard (Phases 2 & 6)
  components/       # shared/presentational components
  test/             # test setup
```

## Still needed before this is customer-ready
- Vendor's WhatsApp number (`VITE_VENDOR_WHATSAPP_NUMBER` in `.env`)
- Real category list + menu items (seed via the admin panel once Phase 2 is built)
- Which items have size/pack variants, and their labels/prices
